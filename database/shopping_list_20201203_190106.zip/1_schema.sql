SET FOREIGN_KEY_CHECKS=0; SET UNIQUE_CHECKS=0; 
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `item` (
  `itemid` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `dateupdated` datetime DEFAULT NULL,
  `datedeleted` datetime DEFAULT NULL,
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `itemid_UNIQUE` (`itemid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 ;
/*!40101 SET character_set_client = @saved_cs_client */;
SET FOREIGN_KEY_CHECKS=1; SET UNIQUE_CHECKS=1; 
